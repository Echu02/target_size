from pathlib import Path
import hashlib

source_dir = Path(r'E:\Scripts\target_size\labels')
files = list(x for x in source_dir.iterdir() if x.is_file())

# Always set target before running the script
targetX = 20
targetY = 20
count = 0

for i in range(len(files)):
    file = Path(files[i])
    with open(file) as fReader:
        for line in fReader:
            line_split = line.split()
            x1 = int(line_split[4])
            y1 = int(line_split[5])
            x2 = int(line_split[6])
            y2 = int(line_split[7])
            xgen = x2-x1
            ygen = y2-y1

            if line_split[0] == 'gun':
                if xgen <= targetX and ygen <= targetY:
                    count = count + 1
                    print(count)
                    #print(file)
